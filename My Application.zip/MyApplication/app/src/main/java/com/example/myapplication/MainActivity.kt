package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        findViewById<TextView>(R.id.textHello).text = "1"

        textHello.text="1"

    }
    fun addNumber(v: View) {
        val currVal =  findViewById<TextView>(R.id.textHello).text.toString().toInt()
        val nextVal = currVal + 30
        findViewById<TextView>(R.id.textHello).text = nextVal.toString()
    }
}